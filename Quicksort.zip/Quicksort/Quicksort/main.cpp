//
//  main.cpp
//  Quicksort
//
//  Created by Edward Whale on 22/11/2019.
//  Copyright © 2019 Edward Whale. All rights reserved.
//

#include <iostream>
#include <iterator>

using namespace std;

int fillArray(int array[]) {
    for (int i = 0; i<10; i++) {
        int v1 = rand() % 100;
        array[i] = v1;
    }
    return *array;
};

bool sorted(int array[],int high) {
    for (int i = 0; i< high; i++) {
        if (array[i] > array[i+1]) {
            return false;
        }
    }
    return true;
}

void PrintArray(int array[]) {
    for (int i = 0; i<10; i++) {
        cout<<array[i]<<" ";
    }
}

void quickSort(int array[],int pivot,int low) {
    int temp;
    int l = low;
    int r = pivot -1;
    while (r > l) {
        cout<<"Pivot: "<<array[pivot]<<endl;
        cout<<"from Right: "<<array[r]<<endl;
        cout<<"from Left: "<<array[l]<<endl;
        if ((array[r] < array[pivot]) and (array[l] > array[pivot])) {
            temp = array[r];
            array[r] = array[l];
            array[l] = temp;
        }
        else if (array[l] < array[pivot]) {
            l = l + 1;
            if (array[r] > array[pivot]) {
                r = r - 1;
            }
        }
        else if (array[r] > array[pivot]) {
            r = r - 1;
            if (array[l] < array[pivot]) {
                l = l + 1;
            }
        }
    }
    if (array[pivot] < array[l]) {
        temp = array[pivot];
        array[pivot] = array[l];
        array[l] = temp;
    }
    PrintArray(array);
    cout<<"new piv: "<<l<<endl;
    if (sorted(array,pivot) != true) {
        quickSort(array, l-1, 0);
        quickSort(array, pivot, l+1);
    }
}

int main(int argc, const char * argv[]) {
    int SortArray [10];
    fillArray(SortArray);
    PrintArray(SortArray);
    int pivot = 9;
    quickSort(SortArray, pivot, 0);
    PrintArray(SortArray);
    return 0;
}
